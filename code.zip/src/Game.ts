const EMPTY_SYMBOL = " "
const PLAYER_X = "X"
const PLAYER_O = "O"
const BOARD_SIZE = 3

export class Game {
  private _lastSymbol: string = EMPTY_SYMBOL
  private _board: Board = new Board()

  public Play(symbol: string, x: number, y: number): void {
    this.validateMove(symbol, x, y)
    this._lastSymbol = symbol
    this._board.AddTileAt(symbol, x, y)
  }

  private validateMove(symbol: string, x: number, y: number): void {
    if (this._lastSymbol === EMPTY_SYMBOL) {
      if (symbol !== PLAYER_X) {
        throw new Error("Invalid first player")
      }
    } else if (symbol === this._lastSymbol) {
      throw new Error("Invalid next player")
    } else if (this._board.TileAt(x, y).Symbol !== EMPTY_SYMBOL) {
      throw new Error("Invalid position")
    }
  }

  public Winner(): string {
    const rowWinner = this.findWinnerInRows()
    if (rowWinner !== EMPTY_SYMBOL) return rowWinner

    const columnWinner = this.findWinnerInColumns()
    if (columnWinner !== EMPTY_SYMBOL) return columnWinner

    const diagonalWinner = this.findWinnerInDiagonals()
    if (diagonalWinner !== EMPTY_SYMBOL) return diagonalWinner

    return EMPTY_SYMBOL
  }

  private findWinnerInRows(): string {
    for (let row = 0; row < BOARD_SIZE; row++) {
      const winner = this.checkLineWinner(
        this._board.TileAt(row, 0),
        this._board.TileAt(row, 1),
        this._board.TileAt(row, 2),
      )
      if (winner !== EMPTY_SYMBOL) return winner
    }
    return EMPTY_SYMBOL
  }

  private findWinnerInColumns(): string {
    for (let col = 0; col < BOARD_SIZE; col++) {
      const winner = this.checkLineWinner(
        this._board.TileAt(0, col),
        this._board.TileAt(1, col),
        this._board.TileAt(2, col),
      )
      if (winner !== EMPTY_SYMBOL) return winner
    }
    return EMPTY_SYMBOL
  }

  private findWinnerInDiagonals(): string {
    const mainDiagonalWinner = this.checkLineWinner(
      this._board.TileAt(0, 0),
      this._board.TileAt(1, 1),
      this._board.TileAt(2, 2),
    )
    if (mainDiagonalWinner !== EMPTY_SYMBOL) return mainDiagonalWinner

    const antiDiagonalWinner = this.checkLineWinner(
      this._board.TileAt(0, 2),
      this._board.TileAt(1, 1),
      this._board.TileAt(2, 0),
    )
    return antiDiagonalWinner
  }

  private checkLineWinner(tile1: Tile, tile2: Tile, tile3: Tile): string {
    const symbol = tile1.Symbol
    if (symbol !== EMPTY_SYMBOL && symbol === tile2.Symbol && symbol === tile3.Symbol) {
      return symbol
    }
    return EMPTY_SYMBOL
  }

  // These methods are no longer called after refactoring - functionality is now in checkLineWinner()
}

interface Tile {
  X: number
  Y: number
  Symbol: string
}

class Board {
  private _plays: Tile[] = []

  constructor() {
    for (let i = 0; i < BOARD_SIZE; i++) {
      for (let j = 0; j < BOARD_SIZE; j++) {
        const tile: Tile = { X: i, Y: j, Symbol: EMPTY_SYMBOL }
        this._plays.push(tile)
      }
    }
  }

  public TileAt(x: number, y: number): Tile {
    if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE) {
      throw new Error(`Invalid board position: (${x}, ${y})`)
    }
    return this._plays.find((t: Tile) => t.X === x && t.Y === y)!
  }

  public AddTileAt(symbol: string, x: number, y: number): void {
    const tile = this._plays.find((t: Tile) => t.X === x && t.Y === y)!
    tile.Symbol = symbol
  }
}
