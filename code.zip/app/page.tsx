"use client"

import  from "../src/Game.test"

export default function SyntheticV0PageForDeployment() {
  return < />
}